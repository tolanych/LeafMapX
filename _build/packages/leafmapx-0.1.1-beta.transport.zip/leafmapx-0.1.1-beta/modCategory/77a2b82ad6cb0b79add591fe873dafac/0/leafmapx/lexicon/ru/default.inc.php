<?php
include_once 'setting.inc.php';

$_lang['leafmapx'] = 'LeafMapX';
$_lang['leafmapx_menu_desc'] = 'Пример расширения для разработки.';
$_lang['leafmapx_intro_msg'] = 'Вы можете выделять сразу несколько предметов при помощи Shift или Ctrl.';
