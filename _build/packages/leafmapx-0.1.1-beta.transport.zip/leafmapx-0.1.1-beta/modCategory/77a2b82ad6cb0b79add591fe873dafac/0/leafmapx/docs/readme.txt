--------------------
LeafMapX
--------------------
Author: tolanych <tolanych@tut.by>
https://github.com/tolanych/LeafMapX
--------------------

Yet another map on Leaflet for MODX.