<?php

$_lang['area_leafmapx_main'] = 'Основные';

$_lang['setting_leafmapx_some_setting'] = 'Какая-то настройка';
$_lang['setting_leafmapx_some_setting_desc'] = 'Это описание для какой-то настройки';