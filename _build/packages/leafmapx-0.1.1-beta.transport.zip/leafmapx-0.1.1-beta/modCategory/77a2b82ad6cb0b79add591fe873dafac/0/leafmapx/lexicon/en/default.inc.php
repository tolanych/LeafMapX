<?php
include_once 'setting.inc.php';

$_lang['leafmapx'] = 'LeafMapX';
$_lang['leafmapx_menu_desc'] = 'A sample Extra to develop from.';
$_lang['leafmapx_intro_msg'] = 'You can select multiple items by holding Shift or Ctrl button.';
